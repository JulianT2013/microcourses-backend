const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  instructor: String,
  duration: Number, // in hours
  category: String
}, { timestamps: true });

module.exports = mongoose.model('Course', courseSchema);
